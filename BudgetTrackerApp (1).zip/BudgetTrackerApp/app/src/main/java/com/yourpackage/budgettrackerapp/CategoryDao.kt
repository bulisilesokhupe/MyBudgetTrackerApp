package com.yourpackage.budgettrackerapp

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface CategoryDao {
    @Insert
    suspend fun insert(category: Category)

    @Query("SELECT * FROM Category")
    suspend fun getAll(): List<Category>
}
