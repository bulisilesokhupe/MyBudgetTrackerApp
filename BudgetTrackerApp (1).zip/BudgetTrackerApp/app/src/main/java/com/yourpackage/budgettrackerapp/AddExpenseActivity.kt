package com.yourpackage.budgettrackerapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class AddExpenseActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_expense)

        val desc = findViewById<EditText>(R.id.expenseDesc)
        val amount = findViewById<EditText>(R.id.expenseAmount)
        val saveBtn = findViewById<Button>(R.id.saveBtn)

        val db = AppDatabase.getDatabase(this)

        saveBtn.setOnClickListener {
            val descText = desc.text.toString()
            val amountVal = amount.text.toString().toDoubleOrNull()

            if (descText.isEmpty() || amountVal == null) {
                Toast.makeText(this, "Fill in valid data", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            GlobalScope.launch {
                db.expenseDao().insert(Expense(0, descText, amountVal))
                runOnUiThread {
                    Toast.makeText(this@AddExpenseActivity, "Saved", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }
    }
}
